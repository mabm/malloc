/*
** main.c for  in /home/jobertomeu/Work/malloc
** 
** Made by Joris Bertomeu
** Login   <jobertomeu@epitech.net>
** 
** Started on  Thu Feb  5 11:11:33 2015 Joris Bertomeu
** Last update Tue Feb 10 13:26:34 2015 Joris Bertomeu
*/

#include	<math.h>
#include	"malloc.h"

static		t_malloc *freep = NULL;
static int	nbMallocd = 0;
static		nbMalloc = 0;

void		show_list(t_malloc *ptr, char *str)
{
  t_malloc	*tmp = ptr;

  printf("---------- %s ----------\n", str);
  while (tmp)
    {
      printf("Size :\t\t%d\n", tmp->size);
      printf("Origi:\t\t%d\n", tmp->original);
      printf("Ptr. :\t\t%p\n", tmp->ptr);
      printf("Next :\t\t%p\n", tmp->next);
      tmp = tmp->next;
      printf("-------\n");
    }
}

void	my_putchar(char c)
{
  write(1, &c, 1);
}

void    my_put_nbr(int nb)
{
  int   neg;

  neg = 0;
  if (nb < 0)
    {
      my_putchar('-');
      if (nb == -2147483648)
        {
          neg = 1;
          nb++;
        }
      nb = nb * -1;
    }
  if (nb >= 10)
    my_put_nbr(nb / 10);
  if (neg == 1)
    {
      neg = 0;
      my_putchar(nb % 10 + '1');
    }
  else
    my_putchar(nb % 10 + '0');
}

void		*choice_return(t_malloc *tmpf, t_malloc *nodef, void *ptr)
{
  if (!tmpf)
    freep = nodef;
  else
    tmpf->next = nodef;
  return (ptr);
}

size_t		calc_requested_size(size_t size)
{
  size_t	ret = getpagesize();

  while (ret < size)
    ret += getpagesize();
  return (ret);
}

void		my_write(char *str)
{
  write(1, str, strlen(str));
}

void		*new_alloc(size_t size)
{
  void		*ptr;
  t_malloc	*nodef = sbrk(sizeof(t_malloc));
  t_malloc	*tmpf = freep;
  size_t	request;

  request = calc_requested_size(size);
  my_write("NA1 requested : ");
  my_put_nbr(size);
  my_write("\n");
  while (tmpf && tmpf->next)
    tmpf = tmpf->next;
  ptr = sbrk(request);
  if (ptr == (void*) -1)
    _exit(127);
  nbMallocd += request;
  bzero(ptr, size);
  ((t_header*) ptr)->size = size - sizeof(t_header);
  nodef->size = request - size;
  nodef->ptr = ptr + size;
  nodef->next = NULL;
  nodef->original = request;
  nodef->ptr_original = ptr;
  return (choice_return(tmpf, nodef, ptr + sizeof(t_header)));
}

void		*crop_in_freep(size_t size, t_malloc *ptr)
{
  my_write("CROP\n");
  ((t_header*) ptr->ptr)->size = size - sizeof(t_header);
  my_write("CROP2\n");
  ptr->size -= size;
  my_write("CROP3\n");
  ptr->ptr = ptr->ptr + size;
  my_write("CROP4\n");
  return (ptr->ptr - size + sizeof(t_header));
}

void		*search_in_freep(size_t size)
{
  t_malloc	*tmp = freep;

  my_write("SIF1\n");
  while (tmp)
    {
      my_write("BOUCLE\n");
      if (tmp->size >= size)
	return (crop_in_freep(size, tmp));
      tmp = tmp->next;
    }
  my_write("SIF2\n");
  return (new_alloc(size));
}

size_t	get_real_size(size_t size)
{
  float	i = 1;

  while (i <= size) {
    printf("i = %f\n", i);
    i = pow(i, 2);
  }
  return (i);
}

void	*malloc(size_t size)
{
  if (!size)
    return (NULL);
  write(1, "MALLOC\n", 7);
  size = size + sizeof(t_header);
  nbMalloc++;
  my_write("Size mallocd : ");
  my_put_nbr(size);
  my_write("\n");
  my_write("MC\n");
  if (!freep)
    return (new_alloc(size));
  else
    return (search_in_freep(size));
}

void		*realloc(void *ptr, size_t size)
{
  void		*tmp;
  t_malloc	*old_ptr;

  if (!ptr)
    return (NULL);
  //write(1, "REALLOC\n", 8);
  size = size + sizeof(t_header);
  my_write("REALLOC\n");
  my_write("size old : ");
  my_put_nbr(((t_header*) (ptr - sizeof(t_header)))->size);
  my_write("\n");
  tmp = malloc(size);
  memcpy(tmp, ptr - sizeof(t_header), ((t_header*) (ptr - sizeof(t_header)))->size + sizeof(t_header));
  ((t_malloc*) (tmp - sizeof(t_header)))->size = size;
  free(ptr);
  return (tmp);
}

void		check_possible_fusion()
{
  t_malloc	*tmp = freep;

  
}

void		free(void *ptr)
{
  t_header	*header;
  t_malloc	*tmp = freep;
  int		size = 0;

  if (!ptr)
    return;
  write(1, "FREE\n", 5);
  my_write("FREE\n");
  size = ((t_header*) (ptr - sizeof(t_header)))->size + sizeof(t_header);
  my_write("Size freeing : ");
  my_put_nbr(size);
  my_write("\n");
  my_write("FREE2\n");
  show_list(freep, "Free");
  while (ptr - sizeof(t_header) != tmp->ptr - size && tmp->next)
    tmp = tmp->next;
  if (ptr - sizeof(t_header) == tmp->ptr - size) {
    write(1, "FUSION\n", 7);
    tmp->size += size;
    tmp->ptr -= size;
    return;
  }
  my_write("FREE3\n");
  tmp->next = sbrk(sizeof(t_malloc));
  ((t_malloc*) tmp->next)->size = size;
  ((t_malloc*) tmp->next)->original = -1;
  ((t_malloc*) tmp->next)->ptr_original = NULL;
  ((t_malloc*) tmp->next)->ptr = ptr - sizeof(t_header);
  ((t_malloc*) tmp->next)->next = NULL;
  check_possible_fusion();
  my_write("SBRK: ");
  my_put_nbr(nbMallocd);
  my_write("\n");
}

/* int	main() */
/* { */
/*   int	start = 10, size = start + 2, incr = 1; */
/*   void	*foo[size]; */
/*   int	i = 0; */

/*   foo[i] = malloc(50); */
/*   my_write("APRES MALLOC\n"); */
/*   memset(foo[i], 0, 50); */
/*   memset(foo[i], 'o', 49); */
/*   my_write("APRES MALLOC 2\n"); */
/*   /\* foo[i] = realloc(foo[i], 100); *\/ */
/*   /\* //printf("%s\n", foo[i]); *\/ */
/*   /\* memset(foo[i], 0, 100); *\/ */
/*   /\* memset(foo[i], 'o', 99); *\/ */
/*   /\* free(foo[i]); *\/ */
/*   /\* exit(0); *\/ */
/*   /\* for (i = start; i < size; i += incr) { *\/ */
/*   /\*   foo[i] = malloc(i); *\/ */
/*   /\*   memset(foo[i], 0, i); *\/ */
/*   /\*   memset(foo[i], 'o', i - 1); *\/ */
/*   /\*   foo[i] = realloc(foo[i], i + 50); *\/ */
/*   /\*   //printf("%s\n", foo[i]); *\/ */
/*   /\*   memset(foo[i], 0, i + 50); *\/ */
/*   /\*   memset(foo[i], 'o', (i + 50) - 1); *\/ */
/*   /\* } *\/ */
/*   /\* /\\* show_list(freep, "Freep"); *\\/ *\/ */
/*   /\* for (i = start; i < size; i += incr) { *\/ */
/*   /\*   free(foo[i]); *\/ */
/*   /\* } *\/ */
/*   /\* printf("\n"); *\/ */
/*   /\* show_list(freep, "Freep"); *\/ */
/* } */
