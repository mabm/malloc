int	main()
{
  char	*tmp = malloc(4096 * sizeof(char));

  free(tmp);
}
